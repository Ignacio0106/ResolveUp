<?php
return [
    'LOG_PATH' => __DIR__ . '/Log',
    'DB_USERNAME' => 'root',
    'DB_PASSWORD' => '123456',
    'DB_HOST' => 'localhost',
    'DB_DBNAME' => 'ResolveUp2',
    'SECRET_KEY'=>'e0d17975bc9bd57eee132eecb6da6f11048e8a88506cc3bffc7249078cf2a77a'
];